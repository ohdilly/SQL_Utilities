SET DEFINE OFF;


SELECT count(*) FROM dba_tables where table_name = 'POST_MIG_CRITERION_COUNTS';
--0
