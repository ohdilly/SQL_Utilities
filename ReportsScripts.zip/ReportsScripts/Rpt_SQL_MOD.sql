SELECT
    icde.file_id,
    icde.status,
    icde.contract_id,
    icde.contract_key,
    icde.batch_seq_num,
    icde.curr_batch_seq_num,
    icde.product_id,
    icde.product_id_type,
    pb.prod_desc,
    icde.product_key,
    icde.curr_product_key,
    icde.product_description,
	az.product_family,
    icde.rx_id,
    trunc(icde.fill_date) fill_date,
    trunc(icde.curr_fill_date) curr_fill_date,
    icde.pharmacy_id_qualifier,
    icde.pharmacy_id,
    icde.pharmacy_key,
    icde.pharmacy_master,
    icde.total_prescriptions,
    icde.curr_total_prescriptions,
    icde.rebate_days_supply,
    icde.curr_rebate_days_supply,
    icde.quantity,
    icde.curr_quantity,
    icde.gap_amt_prev,
    icde.curr_gap_amt_prev,
    icde.gap_amt_curr,
    icde.curr_gap_amt_curr,
    icde.gap_amt_pd,
    icde.curr_gap_amt_pd,
    icde.report_id,
    icde.detail_ref_num,
    icde.prev_rpt_id,
    icde.prev_reporting_pd,
    icde.curr_reporting_pd,
    icde.critical_errors,
    icde.cg_data_detail_id,
    icde.cg_data_lablr_id,
    icde.cg_manuf_rec_id,
    icde.cbmbo_errors,
    icde.overriden_errors,
    icde.warning_errors,
    icde.validation_included,
    icde.validation_excluded,
    icde.dup_processed,
    icde.refill_type,
    icde.curr_refill_type,
    icde.dispute_status,
    icde.dispute_reasons,
    icde.dispute_primary_reason,
    icde.dispute_edits,
    icde.dispute_resolution_text,
    icde.filler,
    icde.dispute_txt_flg,
    pb.wac_start_date,
    pb.wac_end_date,
    pb.wac,
    ( icde.quantity * wac ) gross_sales
FROM
    validata.ivd_cg_data_detail icde,
	AZ_IVDVC_PRODUCT_DETAIL az,
    (
SELECT
    prod.prod_num,
    prod.prod_desc,
    prod.prod_identifier,
    pbasis_unit wac,
    pbasis.pbasis_dt_effective wac_start_date,
    trunc(pbasis.END_DATE) wac_end_date
FROM
    IVDVCG_PBASIS_PRICE_DATE pbasis,
    ivdvcg_product prod
WHERE
    pbasis.prod_num = prod.prod_num
    and pbasis.PBASISCD_ID ='WAC'
    ) pb
WHERE
    icde.product_id = pb.prod_identifier(+)
	AND az.prod_num = pb.prod_num
    AND   (
        ( icde.fill_date BETWEEN wac_start_date AND wac_end_date )
        OR    wac_start_date IS NULL
    )
    AND   file_id =?;