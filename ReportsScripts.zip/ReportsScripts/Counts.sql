--Criterion Count START

SELECT
    dest.query_name,
    dest.criterion,
    dest.criterion_type,
    nvl(dest.count,0) Post_Count,
    nvl(src.COUNT,0) Pre_Count,
    nvl((dest.count - src.count),0) DIFF
FROM
    pre_exp_mig_criterion_counts dest,
    post_mig_criterion_counts src
WHERE
    dest.query_id = src.query_id
    AND   dest.query_name = src.query_name
    AND   dest.criterion = src.criterion
    AND   nvl(dest.count,0) = nvl(src.count,0)
union
SELECT
    dest.query_name,
    dest.criterion,
    dest.criterion_type,
    nvl(dest.count,0) Post_Count,
    nvl(src.COUNT,0) Pre_Count,
    nvl((dest.count - src.count),0) DIFF
FROM
    pre_exp_mig_criterion_counts dest,
    post_mig_criterion_counts src
WHERE
    dest.query_id = src.query_id
    AND   dest.query_name = src.query_name
    AND   dest.criterion = src.criterion
    AND   nvl(dest.count,0) <> nvl(src.count,0)

ORDER BY
    1 ASC;

--Row Counts
Select distinct a.table_name, a.count Pre_Count, b.count Post_Count, ABS((a.count-b.count)) DIFF
from VALIDATA.PRE_EXP_FLEX_VD_MIG_ROW_COUNTS a,
VALIDATA.POST_EXP_FLEX_VD_MIG_ROW_COUNTS b
where a.table_name = b.table_name
And a.table_name not like 'PRE%'
And a.table_name not like 'POST%'
order by 1;