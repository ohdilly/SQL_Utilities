SET DEFINE OFF;


SELECT count(*) FROM dba_tables where table_name = 'POST_EXP_FLEX_VD_MIG_ROW_COUNTS';
--0
